<?php
/* ----------- Server configuration ---------- */

$ip = "159.253.37.137";
$port = "9842";

/* ----- No need to edit below this line ----- */
/* ------------------------------------------- */

$fp = @fsockopen($ip,$port,$errno,$errstr,1);
if (!$fp) 
	{ 
	echo "Connection refused"; // Displays when sever is offline
	} 
	else
	{ 
	fputs($fp, "GET /7.html HTTP/1.0\r\nUser-Agent: Mozilla\r\n\r\n");
	while (!feof($fp)) 
		{
		$info = fgets($fp);
		}
	$info = str_replace('</body></html>', "", $info);
	$split = explode(',', $info);
	if (empty($split[6]) )
		{
		echo "The current song is not available"; // Displays when sever is online but no song title
		}
	else
		{
		$title = str_replace('\'', '`', $split[6]);
		$title = str_replace(',', ' ', $title);
		echo " <h2><strong> Şu anki içerik : $title </strong></h2>"; // Displays song
		}
	}
?>
<form action="http://www.google.com.tr/search?q=" method="get"> 
 <input type="hidden" name="q" size="15" value="<?php echo $title; ?>"> 
<input type="submit" value=" google 'da ara: <?php echo $title; ?>">
</form>


<!DOCTYPE html>
<html lang="pt-BR">

<head>
    <meta charset="utf-8">
    <title>Radyo Engelsiz Erişim</title>
    <meta name="description" content="HTML5 Player for SHOUTCast streaming">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="theme-color" content="#171717">
    <meta property="og:url" content="http://gsavio.github.io/player-shoutcast-html5">
    <meta property="og:title" content="I'm listening Rock FM!">
    <meta property="og:site_name" content="Não deixe o Rock sair de você">
    <meta property="og:description" content="">
    <meta property="og:image" content="img/bg-capa.jpg">
    <meta property="og:image:type" content="image/jpeg">
    <meta property="og:image:width" content="512">
    <meta property="og:image:height" content="512">
    <link rel="icon" type="image/png" href="img/logo.png" />
    <link rel="stylesheet" href="css/font-awesome.min.css">
    <link rel="stylesheet" type="text/css" href="css/animate.css">
    <link rel="stylesheet" href="css/style.css">
</head>

<body>
    
</form>
    <main>


<img src="http://www.engelsizerisim.com/assets/images/logo-ee.png" alt="Sol tarafta yarım ay biçiminde latin alfabesiyle, aşağıda braille alfabesiyle Engelsiz Erişim yazısı ve ortada güneşin içinde uçan bir kuş..." title="Sol tarafta yarım ay biçiminde latin alfabesiyle, aşağıda braille alfabesiyle Engelsiz Erişim yazısı ve ortada güneşin içinde uçan bir kuş...">
    
<audio controls autoplay="autoplay"><source src="http://159.253.37.137:9842/;stream.mp3" type="audio/mp3">Your browser does not support the audio element.</audio>

<!-- END: SHOUTCASTWIDGETS.COM -- FREE HTML5 PLAYER SHOUTCAST ICECAST GENERATOR -->


<a href="http://159.253.37.137:9842/currentsong?sid=#" >Çalan içeriğe gözatın</a>
<a href="http://www.engelsizerisim.com/mesajpanosu/" accesskey="m">Bize mesaj yazın</a>
<br>
<h5>E-posta Adresimiz:</h5>
    <a href="mailto:mail@engelsizerisim.com" accesskey="m">mail@engelsizerisim.com</a>
    <h5>Web:</h5>
    <a href="http://www.engelsizerisim.com" accesskey="e">http://www.engelsizerisim.com</a>
    <h5>Sosyal Medya:</h5>
    <a href="https://www.facebook.com/engelsizerisimdernegi" accesskey="f">Facebook/engelsizerisimdernegi</a>
    <a href="https://twitter.com/engelsizerisim" accesskey="t">Twitter/engelsizerisim</a>
    <a href="https://www.youtube.com/channel/UCa3Fs7nGRB6EXArOJ2pAMLA" accesskey="y">Youtube/Engelsiz Erişim</a>
    <a href="https://www.youtube.com/channel/UChihxjgpqsCVfX3wC3vUMtA" accesskey="u">Youtube/Engelsiz Eğitim</a>
<a href="https://www.instagram.com/engelsizerisimdernegi/?igshid=i6vb9pag7s42" accesskey="i">Instagram/Engelsiz Erişim Derneği</a>

</body>
</html>